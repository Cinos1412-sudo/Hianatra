"use client";

import { useState } from "react";

export type GeminiMode = "eli5" | "flashcards" | "digest";

interface FlashcardResult {
  front: string;
  back: string;
}

export function useGemini() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function run(mode: GeminiMode, input: string) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/gemini", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode, input }),
      });
      if (!res.ok) throw new Error(`Erreur API Gemini (${res.status})`);
      const data = await res.json();
      return data as { text?: string; flashcards?: FlashcardResult[] };
    } catch (e) {
      setError(e instanceof Error ? e.message : "Erreur inconnue");
      return null;
    } finally {
      setLoading(false);
    }
  }

  const explainLikeImFive = (concept: string) => run("eli5", concept);
  const generateFlashcards = (noteContent: string) => run("flashcards", noteContent);
  const generateDailyDigest = (studySummary: string) => run("digest", studySummary);

  return { loading, error, explainLikeImFive, generateFlashcards, generateDailyDigest };
}
