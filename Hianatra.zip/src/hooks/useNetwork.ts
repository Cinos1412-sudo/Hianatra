"use client";

import { useEffect, useState } from "react";

/**
 * Écoute window.addEventListener('online' | 'offline') et expose l'état réseau courant.
 * Sert de déclencheur pour la synchronisation en arrière-plan (voir useOfflineStorage.syncPending).
 */
export function useNetwork() {
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    setIsOnline(navigator.onLine);

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  return isOnline;
}
