"use client";

import Dexie, { type EntityTable } from "dexie";
import { useLiveQuery } from "dexie-react-hooks";
import { useEffect } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useNetwork } from "./useNetwork";

export interface NoteRecord {
  id?: number;
  title: string;
  content: string;
  chapter: string;
  reviewType: "Théorie" | "Pratique" | "OCR + Fiches";
  createdAt: string;
  synced: boolean;
}

export interface PendingSyncRecord {
  id?: number;
  table: "notes";
  recordId: number;
  operation: "insert" | "update" | "delete";
  payload: unknown;
  createdAt: string;
}

class LearningAppDB extends Dexie {
  notes!: EntityTable<NoteRecord, "id">;
  pending_sync!: EntityTable<PendingSyncRecord, "id">;

  constructor() {
    super("learning-app-db");
    this.version(1).stores({
      notes: "++id, chapter, reviewType, synced, createdAt",
      pending_sync: "++id, table, recordId, operation, createdAt",
    });
  }
}

export const db = new LearningAppDB();

/**
 * Toute écriture utilisateur passe d'abord ici (IndexedDB), de façon synchrone,
 * avant toute tentative de jointure vers Supabase — conformément au blueprint.
 */
export function useOfflineStorage() {
  const isOnline = useNetwork();
  const notes = useLiveQuery(() => db.notes.orderBy("createdAt").reverse().toArray(), [], []);
  const pendingCount = useLiveQuery(() => db.pending_sync.count(), [], 0);

  async function saveNote(note: Omit<NoteRecord, "id" | "synced" | "createdAt">) {
    const createdAt = new Date().toISOString();
    const id = await db.notes.add({ ...note, synced: false, createdAt });
    await db.pending_sync.add({
      table: "notes",
      recordId: id,
      operation: "insert",
      payload: { ...note, createdAt },
      createdAt,
    });
    return id;
  }

  async function syncPending() {
    if (!isOnline) return;

    const batch = await db.pending_sync.toArray();
    if (batch.length === 0) return;

    const rows = batch
      .filter((b) => b.operation !== "delete")
      .map((b) => ({ ...(b.payload as object), id: b.recordId }));

    if (rows.length > 0) {
      const { error } = await supabase.from("notes").upsert(rows);
      if (error) {
        console.error("Échec de synchronisation Supabase :", error.message);
        return; // on garde la file pending_sync intacte pour réessayer plus tard
      }
    }

    // Succès : on nettoie la table locale et on marque les notes comme synchronisées
    await db.transaction("rw", db.notes, db.pending_sync, async () => {
      for (const item of batch) {
        await db.notes.update(item.recordId, { synced: true });
        await db.pending_sync.delete(item.id!);
      }
    });
  }

  // Déclenchement automatique de la synchro par lot au retour du réseau
  useEffect(() => {
    if (isOnline) syncPending();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOnline]);

  return {
    notes: notes ?? [],
    pendingCount: pendingCount ?? 0,
    isOnline,
    saveNote,
    syncPending,
  };
}
