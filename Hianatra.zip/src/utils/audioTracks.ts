export interface AudioTrack {
  id: string;
  label: string;
  url: string; // Boucle CC0 hébergée sur CDN
}

// Remplace ces URLs par tes propres boucles CC0 hébergées (ex: Cloudflare R2, Supabase Storage).
export const AUDIO_TRACKS: AudioTrack[] = [
  { id: "rain", label: "Pluie", url: "https://cdn.example.com/audio/rain-loop.mp3" },
  { id: "lofi", label: "Lo-Fi", url: "https://cdn.example.com/audio/lofi-loop.mp3" },
  { id: "binaural", label: "Binaural focus", url: "https://cdn.example.com/audio/binaural-loop.mp3" },
];
