/**
 * Variante simplifiée de l'algorithme SM-2 (SuperMemo).
 * Calcule le prochain intervalle de révision (I) à partir du score utilisateur (1 à 5)
 * puis en déduit la date de la prochaine révision : D_next = D (aujourd'hui) + I jours.
 */

export interface ReviewState {
  repetition: number; // nombre de révisions réussies consécutives
  easeFactor: number; // facteur de facilité (>= 1.3)
  interval: number; // intervalle en jours avant la prochaine révision
}

export interface ReviewResult extends ReviewState {
  nextReviewDate: string; // ISO 8601
}

export const DEFAULT_REVIEW_STATE: ReviewState = {
  repetition: 0,
  easeFactor: 2.5,
  interval: 0,
};

/**
 * @param quality Score de 1 (raté) à 5 (parfait) donné par l'utilisateur sur la carte
 * @param state État précédent de la carte (issu d'IndexedDB / Supabase)
 * @param today Date de référence (par défaut aujourd'hui), utile pour les tests
 */
export function scheduleNextReview(
  quality: 1 | 2 | 3 | 4 | 5,
  state: ReviewState = DEFAULT_REVIEW_STATE,
  today: Date = new Date()
): ReviewResult {
  let { repetition, easeFactor, interval } = state;

  if (quality < 3) {
    // Échec : on repart de zéro sur la répétition, mais on garde l'ease factor
    repetition = 0;
    interval = 1;
  } else {
    repetition += 1;
    if (repetition === 1) interval = 1;
    else if (repetition === 2) interval = 6;
    else interval = Math.round(interval * easeFactor);

    easeFactor = Math.max(
      1.3,
      easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))
    );
  }

  const nextReviewDate = new Date(today);
  nextReviewDate.setDate(nextReviewDate.getDate() + interval);

  return {
    repetition,
    easeFactor: Number(easeFactor.toFixed(2)),
    interval,
    nextReviewDate: nextReviewDate.toISOString(),
  };
}

/** Regroupe une liste de cartes par nombre de jours restants avant leur prochaine échéance. */
export function dueToday<T extends { nextReviewDate: string }>(cards: T[], today: Date = new Date()): T[] {
  const end = new Date(today);
  end.setHours(23, 59, 59, 999);
  return cards.filter((c) => new Date(c.nextReviewDate) <= end);
}
