import { NextRequest, NextResponse } from "next/server";
import webpush from "web-push";

// Génère les clés VAPID avec `npx web-push generate-vapid-keys` et place-les dans .env.local
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY ?? "";
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY ?? "";

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails("mailto:contact@learning-app.dev", VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
}

interface PushPayload {
  subscription: webpush.PushSubscription;
  title: string;
  body: string;
}

export async function POST(req: NextRequest) {
  if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
    return NextResponse.json({ error: "Clés VAPID manquantes (.env.local)" }, { status: 500 });
  }

  const { subscription, title, body } = (await req.json()) as PushPayload;

  try {
    await webpush.sendNotification(subscription, JSON.stringify({ title, body }));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return NextResponse.json({ error: (err as Error).message }, { status: 502 });
  }
}
