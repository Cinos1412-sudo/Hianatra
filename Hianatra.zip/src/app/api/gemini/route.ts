import { NextRequest, NextResponse } from "next/server";

export const runtime = "edge";

const GEMINI_ENDPOINT =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

const SYSTEM_PROMPTS: Record<string, string> = {
  eli5:
    "Agis comme un pédagogue d'élite. Tu dois expliquer le concept technique envoyé par l'utilisateur en utilisant une analogie ultra-simple adaptée à un enfant de 5 ans. Reste concis (maximum 3 phrases).",
  flashcards:
    "Analyse la note suivante et extrait les définitions et concepts clés sous forme d'un tableau JSON d'objets possédant les clés 'front' (la question) et 'back' (la réponse). Renvoie uniquement du JSON strict.",
  digest:
    "Génère un script d'encouragement de 150 mots résumant la productivité de l'utilisateur aujourd'hui. Ton ton doit être chaleureux, motivant et calme.",
};

export async function POST(req: NextRequest) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return NextResponse.json(
      { error: "GEMINI_API_KEY manquante côté serveur (.env.local)" },
      { status: 500 }
    );
  }

  const { mode, input } = (await req.json()) as { mode: keyof typeof SYSTEM_PROMPTS; input: string };
  const systemPrompt = SYSTEM_PROMPTS[mode];
  if (!systemPrompt) {
    return NextResponse.json({ error: `Mode inconnu: ${mode}` }, { status: 400 });
  }

  const geminiRes = await fetch(`${GEMINI_ENDPOINT}?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents: [{ role: "user", parts: [{ text: input }] }],
    }),
  });

  if (!geminiRes.ok) {
    const errText = await geminiRes.text();
    return NextResponse.json({ error: `Erreur Gemini: ${errText}` }, { status: 502 });
  }

  const data = await geminiRes.json();
  const text: string = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";

  if (mode === "flashcards") {
    try {
      const flashcards = JSON.parse(text.replace(/```json|```/g, "").trim());
      return NextResponse.json({ flashcards });
    } catch {
      return NextResponse.json({ error: "Réponse JSON invalide de Gemini", raw: text }, { status: 502 });
    }
  }

  return NextResponse.json({ text });
}
