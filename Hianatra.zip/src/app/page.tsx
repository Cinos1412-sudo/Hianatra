"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

const MOBILE_BREAKPOINT = 768;

/**
 * Routeur d'affichage intelligent : redirige vers la vue optimisée
 * selon la largeur de l'écran (Mobile vs PC), conformément au blueprint.
 */
export default function HomePage() {
  const router = useRouter();
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    function redirect() {
      const isMobile = window.innerWidth < MOBILE_BREAKPOINT;
      router.replace(isMobile ? "/dashboard/mobile" : "/dashboard/web");
    }
    redirect();
    setChecked(true);
    window.addEventListener("resize", redirect);
    return () => window.removeEventListener("resize", redirect);
  }, [router]);

  if (!checked) return null;

  return (
    <div className="min-h-screen flex items-center justify-center text-slate-400 text-sm">
      Redirection…
    </div>
  );
}
