import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Learning App",
  description: "Application d'apprentissage offline-first avec révision espacée et assistant IA",
  manifest: "/manifest.json",
};

export const viewport = {
  themeColor: "#0f172a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className="bg-gradient-to-br from-orange-50 via-rose-50 to-slate-100 min-h-screen">
        {children}
      </body>
    </html>
  );
}
