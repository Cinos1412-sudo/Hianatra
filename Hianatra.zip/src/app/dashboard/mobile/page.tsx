"use client";

import { useMemo, useState } from "react";
import { Home, PenLine, CalendarDays, Bell, Search, WifiOff, BookOpen, Sparkles, Flame } from "lucide-react";
import { GlassCard } from "@/components/ui/GlassCard";
import { QuickCalendar } from "@/components/dashboard/QuickCalendar";
import { ScheduleList } from "@/components/dashboard/ScheduleList";
import { ActiveTracking } from "@/components/dashboard/ActiveTracking";
import { StatsPanel, RetentionChart, Eli5Widget, AudioDigestWidget } from "@/components/dashboard/AiWidgets";
import { useOfflineStorage } from "@/hooks/useOfflineStorage";

const CARDS_TODAY = 68;
const MASTERED_MONTH = 42;

export default function MobileDashboardPage() {
  const { isOnline, pendingCount } = useOfflineStorage();
  const [simOffline, setSimOffline] = useState(false);
  const online = simOffline ? false : isOnline;

  const summary = useMemo(
    () => `${CARDS_TODAY} cartes travaillées, 3h40 de focus en série, chapitre Anatomie terminé.`,
    []
  );

  return (
    <div className="min-h-screen p-3 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-300 to-rose-300 flex items-center justify-center text-white font-semibold">
            C
          </div>
          <div>
            <p className="text-slate-500 text-xs">Bonjour,</p>
            <h1 className="text-base font-semibold text-slate-800 leading-tight">Cécillia Funi</h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="w-9 h-9 rounded-2xl bg-white/40 flex items-center justify-center">
            <Search size={14} className="text-slate-500" />
          </button>
          <button
            onClick={() => setSimOffline((s) => !s)}
            className="relative w-9 h-9 rounded-2xl bg-orange-400 text-white flex items-center justify-center"
          >
            <Bell size={14} />
            {!online && pendingCount > 0 && (
              <span className="absolute -top-1 -right-1 text-[9px] bg-slate-900 text-white rounded-full w-4 h-4 flex items-center justify-center">
                {pendingCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {!online && (
        <div className="mb-4 text-xs px-4 py-2 rounded-2xl bg-slate-900 text-amber-200 flex items-center gap-2">
          <WifiOff size={13} /> Hors-ligne — synchro en attente
        </div>
      )}

      <div className="space-y-4">
        {/* Écran 1 : Accueil */}
        <div className="grid grid-cols-2 gap-3">
          <GlassCard className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-rose-200/70 flex items-center justify-center">
              <BookOpen size={15} className="text-rose-600" />
            </div>
            <div>
              <p className="text-lg font-bold text-slate-800">40</p>
              <p className="text-[10px] text-slate-500">Chapitres actifs</p>
            </div>
          </GlassCard>
          <GlassCard className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-teal-200/70 flex items-center justify-center">
              <Sparkles size={15} className="text-teal-600" />
            </div>
            <div>
              <p className="text-lg font-bold text-slate-800">{CARDS_TODAY}</p>
              <p className="text-[10px] text-slate-500">Cartes à revoir</p>
            </div>
          </GlassCard>
        </div>

        <Eli5Widget />
        <ActiveTracking />

        {/* Écran 2 : Calendrier & Horaires */}
        <QuickCalendar />
        <ScheduleList />

        {/* Écran 3 : Suivi d'activité & Statistiques */}
        <StatsPanel cardsToday={CARDS_TODAY} masteredThisMonth={MASTERED_MONTH} />
        <RetentionChart />
        <AudioDigestWidget studySummary={summary} />
      </div>

      {/* Bottom nav */}
      <nav className="fixed bottom-3 inset-x-3 bg-slate-900 rounded-3xl px-6 py-3 flex justify-between items-center shadow-lg">
        <button className="text-white">
          <Home size={18} />
        </button>
        <button className="text-slate-500">
          <PenLine size={18} />
        </button>
        <button className="text-slate-500">
          <CalendarDays size={18} />
        </button>
        <button className="text-slate-500">
          <Flame size={18} />
        </button>
      </nav>
    </div>
  );
}
