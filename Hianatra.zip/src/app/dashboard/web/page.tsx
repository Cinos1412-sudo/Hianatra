"use client";

import { useMemo, useState } from "react";
import { Home, PenLine, CalendarDays, RefreshCw, BarChart2, Settings, Search, Bell, WifiOff, BookOpen, Sparkles } from "lucide-react";
import { GlassCard } from "@/components/ui/GlassCard";
import { QuickCalendar } from "@/components/dashboard/QuickCalendar";
import { ScheduleList } from "@/components/dashboard/ScheduleList";
import { ActiveTracking } from "@/components/dashboard/ActiveTracking";
import { StatsPanel, RetentionChart, NextNotificationCard, Eli5Widget, AudioDigestWidget } from "@/components/dashboard/AiWidgets";
import { FlowPlayer } from "@/components/ui/FlowPlayer";
import { useOfflineStorage } from "@/hooks/useOfflineStorage";

const NAV = [
  { icon: Home, label: "Accueil" },
  { icon: PenLine, label: "Bloc-notes" },
  { icon: CalendarDays, label: "Calendrier" },
  { icon: RefreshCw, label: "Synchro" },
  { icon: BarChart2, label: "Statistiques" },
  { icon: Settings, label: "Réglages" },
];

const CARDS_TODAY = 68; // somme des cartes dues du programme du jour
const MASTERED_MONTH = 42;

export default function WebDashboardPage() {
  const { isOnline, pendingCount } = useOfflineStorage();
  const [simOffline, setSimOffline] = useState(false);
  const online = simOffline ? false : isOnline;

  const summary = useMemo(
    () => `${CARDS_TODAY} cartes travaillées, 3h40 de focus en série, chapitre Anatomie terminé.`,
    []
  );

  return (
    <div className="min-h-screen p-4 md:p-6">
      <div className="mx-auto max-w-7xl flex gap-4">
        {/* Sidebar */}
        <aside className="hidden md:flex flex-col items-center gap-5 bg-slate-900 rounded-3xl w-16 py-6 shrink-0">
          {NAV.map((n, i) => (
            <button
              key={n.label}
              title={n.label}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition ${
                i === 0 ? "bg-white text-slate-900" : "text-slate-400 hover:text-white"
              }`}
            >
              <n.icon size={18} />
            </button>
          ))}
          <button
            onClick={() => setSimOffline((s) => !s)}
            title="Simuler hors-ligne"
            className="mt-auto w-9 h-9 rounded-xl flex items-center justify-center text-slate-400 hover:text-white"
          >
            <WifiOff size={16} />
          </button>
        </aside>

        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-gradient-to-br from-amber-300 to-rose-300 flex items-center justify-center text-white font-semibold">
                C
              </div>
              <div>
                <p className="text-slate-500 text-xs">Bonjour,</p>
                <h1 className="text-lg font-semibold text-slate-800 leading-tight">Cécillia Funi</h1>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center gap-1.5 text-xs px-3 py-2 rounded-2xl bg-white/30 backdrop-blur-xl border border-white/40">
                <Search size={14} className="text-slate-400" />
                <span className="text-slate-400">Rechercher une note…</span>
              </div>
              <button className="relative w-10 h-10 rounded-2xl bg-orange-400 text-white flex items-center justify-center shadow-sm">
                <Bell size={16} />
                {!online && pendingCount > 0 && (
                  <span className="absolute -top-1 -right-1 text-[10px] bg-slate-900 text-white rounded-full w-4 h-4 flex items-center justify-center">
                    {pendingCount}
                  </span>
                )}
              </button>
            </div>
          </div>

          {!online && (
            <div className="mb-4 text-xs px-4 py-2 rounded-2xl bg-slate-900 text-amber-200 flex items-center gap-2">
              <WifiOff size={13} /> Hors-ligne — {pendingCount} note(s) en attente de synchro locale (IndexedDB)
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr_300px] gap-4">
            {/* LEFT column */}
            <div className="space-y-4 order-2 lg:order-1">
              <div className="grid grid-cols-2 lg:grid-cols-1 gap-3">
                <GlassCard className="p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-rose-200/70 flex items-center justify-center">
                    <BookOpen size={17} className="text-rose-600" />
                  </div>
                  <div>
                    <p className="text-xl font-bold text-slate-800">40</p>
                    <p className="text-[11px] text-slate-500">Chapitres actifs</p>
                  </div>
                </GlassCard>
                <GlassCard className="p-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-teal-200/70 flex items-center justify-center">
                    <Sparkles size={17} className="text-teal-600" />
                  </div>
                  <div>
                    <p className="text-xl font-bold text-slate-800">{CARDS_TODAY}</p>
                    <p className="text-[11px] text-slate-500">Cartes à revoir</p>
                  </div>
                </GlassCard>
              </div>
              <Eli5Widget />
              <AudioDigestWidget studySummary={summary} />
              <FlowPlayer />
            </div>

            {/* MIDDLE column */}
            <div className="space-y-4 order-1 lg:order-2">
              <QuickCalendar />
              <ScheduleList />
              <ActiveTracking />
            </div>

            {/* RIGHT column */}
            <div className="space-y-4 order-3">
              <StatsPanel cardsToday={CARDS_TODAY} masteredThisMonth={MASTERED_MONTH} />
              <RetentionChart />
              <NextNotificationCard />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
