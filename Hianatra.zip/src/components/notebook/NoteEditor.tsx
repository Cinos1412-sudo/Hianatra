"use client";

import { useState } from "react";
import { GlassCard } from "@/components/ui/GlassCard";
import { useOfflineStorage } from "@/hooks/useOfflineStorage";
import { useGemini } from "@/hooks/useGemini";

export function NoteEditor({ chapter }: { chapter: string }) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const { saveNote, pendingCount, isOnline } = useOfflineStorage();
  const { generateFlashcards, loading } = useGemini();

  async function handleSave() {
    if (!title.trim() || !content.trim()) return;

    // Écriture locale d'abord (synchrone du point de vue UX), puis sync/IA en tâche de fond
    await saveNote({ title, content, chapter, reviewType: "Théorie" });
    await generateFlashcards(content);

    setTitle("");
    setContent("");
  }

  return (
    <GlassCard className="p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="font-semibold text-slate-800 text-sm">Note — {chapter}</p>
        <span className="text-[10px] text-slate-500">
          {isOnline ? "En ligne" : `Hors-ligne · ${pendingCount} en attente`}
        </span>
      </div>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Titre de la note"
        className="w-full text-xs bg-white/60 rounded-xl px-3 py-2 outline-none placeholder:text-slate-400 mb-2"
      />
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Écris ta note en markdown…"
        rows={5}
        className="w-full text-xs bg-white/60 rounded-xl px-3 py-2 outline-none placeholder:text-slate-400 mb-2 resize-none"
      />
      <button
        onClick={handleSave}
        disabled={loading}
        className="w-full text-xs font-medium bg-slate-900 text-white rounded-xl py-2 disabled:opacity-50"
      >
        {loading ? "Génération des fiches…" : "Enregistrer et générer des fiches"}
      </button>
    </GlassCard>
  );
}
