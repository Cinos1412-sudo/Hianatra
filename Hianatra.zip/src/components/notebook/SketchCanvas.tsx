"use client";

import { useRef, useState } from "react";
import { ReactSketchCanvas, type ReactSketchCanvasRef } from "react-sketch-canvas";
import { Eraser, Save } from "lucide-react";
import { GlassCard } from "@/components/ui/GlassCard";
import { useOfflineStorage } from "@/hooks/useOfflineStorage";
import { useGemini } from "@/hooks/useGemini";

export function SketchCanvas({ chapter }: { chapter: string }) {
  const canvasRef = useRef<ReactSketchCanvasRef>(null);
  const [saving, setSaving] = useState(false);
  const { saveNote } = useOfflineStorage();
  const { generateFlashcards, loading: generatingCards } = useGemini();

  async function handleSaveAndOcr() {
    if (!canvasRef.current) return;
    setSaving(true);
    try {
      const dataUrl = await canvasRef.current.exportImage("png");

      // 1. Écriture synchrone dans IndexedDB avant tout appel réseau
      await saveNote({
        title: `Croquis — ${chapter}`,
        content: dataUrl,
        chapter,
        reviewType: "OCR + Fiches",
      });

      // 2. OCR + génération de flashcards via Gemini Vision (proxy /api/gemini)
      await generateFlashcards(dataUrl);
      await canvasRef.current.clearCanvas();
    } finally {
      setSaving(false);
    }
  }

  return (
    <GlassCard className="p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="font-semibold text-slate-800 text-sm">Bloc-notes — croquis</p>
        <div className="flex gap-2">
          <button
            onClick={() => canvasRef.current?.clearCanvas()}
            className="w-8 h-8 rounded-xl bg-white/60 flex items-center justify-center text-slate-500"
            aria-label="Effacer"
          >
            <Eraser size={14} />
          </button>
          <button
            onClick={handleSaveAndOcr}
            disabled={saving || generatingCards}
            className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center disabled:opacity-50"
            aria-label="Enregistrer et générer des fiches"
          >
            <Save size={14} />
          </button>
        </div>
      </div>
      <div className="rounded-2xl overflow-hidden border border-white/50 bg-white/70">
        <ReactSketchCanvas
          ref={canvasRef}
          height="220px"
          width="100%"
          strokeWidth={3}
          strokeColor="#1e293b"
        />
      </div>
      {(saving || generatingCards) && (
        <p className="text-[11px] text-slate-500 mt-2">
          {saving ? "Sauvegarde locale (IndexedDB)…" : "Extraction OCR et génération des fiches…"}
        </p>
      )}
    </GlassCard>
  );
}
