"use client";

import { Flame } from "lucide-react";
import { BarChart, Bar, Cell, ResponsiveContainer, XAxis, Tooltip } from "recharts";
import { GlassCard } from "@/components/ui/GlassCard";

interface FocusPoint {
  day: string;
  minutes: number;
  streak?: boolean;
}

const FOCUS_DATA: FocusPoint[] = [
  { day: "2 mai", minutes: 55 },
  { day: "4 mai", minutes: 15 },
  { day: "3 mai", minutes: 220, streak: true },
  { day: "5 mai", minutes: 20 },
  { day: "6 mai", minutes: 90 },
];

export function ActiveTracking() {
  const streakPoint = FOCUS_DATA.find((f) => f.streak);

  return (
    <GlassCard className="p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="font-semibold text-slate-800 text-sm">Temps de focus</p>
        {streakPoint && (
          <span className="flex items-center gap-1 text-xs font-semibold text-emerald-600">
            <Flame size={13} /> {Math.floor(streakPoint.minutes / 60)}h{streakPoint.minutes % 60} en série
          </span>
        )}
      </div>
      <div className="h-32">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={FOCUS_DATA}>
            <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
            <Tooltip cursor={{ fill: "transparent" }} contentStyle={{ borderRadius: 12, fontSize: 11 }} />
            <Bar dataKey="minutes" radius={[10, 10, 10, 10]}>
              {FOCUS_DATA.map((f, i) => (
                <Cell key={i} fill={f.streak ? "#3b82f6" : "#e2e8f0"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </GlassCard>
  );
}
