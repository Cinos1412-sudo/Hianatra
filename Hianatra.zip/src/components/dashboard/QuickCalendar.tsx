"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { GlassCard } from "@/components/ui/GlassCard";

interface DayCell {
  date: number;
  label: string;
  due: number;
  isToday?: boolean;
}

const DAYS: DayCell[] = [
  { date: 17, label: "Sam", due: 2 },
  { date: 19, label: "Lun", due: 3 },
  { date: 20, label: "Mer", due: 6, isToday: true },
  { date: 21, label: "Jeu", due: 3 },
  { date: 22, label: "Ven", due: 3 },
  { date: 22, label: "Sam", due: 3 },
];

export function QuickCalendar() {
  return (
    <GlassCard className="p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="font-semibold text-slate-800 text-sm">Janvier 2026</p>
        <p className="text-[11px] text-slate-500">
          Total aujourd&apos;hui <span className="font-semibold text-slate-700">8h 48min</span>
        </p>
      </div>
      <div className="flex items-center gap-1 overflow-x-auto pb-1">
        <button className="shrink-0 p-1 text-slate-400" aria-label="Semaine précédente">
          <ChevronLeft size={16} />
        </button>
        {DAYS.map((d, i) => (
          <div
            key={`${d.date}-${i}`}
            className={`shrink-0 w-16 rounded-2xl py-2 px-2 text-center ${
              d.isToday ? "bg-slate-900 text-white" : "bg-white/50 text-slate-600"
            }`}
          >
            <p className="text-[10px] opacity-70">{d.label}</p>
            <p className="text-sm font-semibold">{d.date}</p>
            <p className="text-[9px] opacity-80">{d.due} cartes</p>
          </div>
        ))}
        <button className="shrink-0 p-1 text-slate-400" aria-label="Semaine suivante">
          <ChevronRight size={16} />
        </button>
      </div>
    </GlassCard>
  );
}
