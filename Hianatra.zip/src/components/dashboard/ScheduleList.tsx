import { GlassCard } from "@/components/ui/GlassCard";

interface ScheduleItem {
  time: string;
  title: string;
  type: "Théorie" | "Pratique" | "OCR + Fiches";
  cards: number;
  color: string;
}

const SCHEDULE: ScheduleItem[] = [
  { time: "07:00", title: "Réseaux de neurones", type: "Théorie", cards: 12, color: "bg-orange-400/90" },
  { time: "08:00", title: "Vocabulaire japonais", type: "Pratique", cards: 20, color: "bg-amber-400/90" },
  { time: "08:30", title: "Anatomie — croquis", type: "OCR + Fiches", cards: 8, color: "bg-rose-300/90" },
  { time: "10:30", title: "Thermodynamique", type: "Théorie", cards: 5, color: "bg-sky-400/90" },
  { time: "12:45", title: "Design Thinking", type: "Théorie", cards: 14, color: "bg-slate-700/90 text-white" },
  { time: "13:50", title: "Illustration", type: "Pratique", cards: 9, color: "bg-emerald-400/90" },
];

export function ScheduleList() {
  const totalCards = SCHEDULE.reduce((sum, s) => sum + s.cards, 0);

  return (
    <GlassCard className="p-4">
      <div className="flex items-center justify-between mb-3">
        <p className="font-semibold text-slate-800 text-sm">Programme du jour</p>
        <span className="text-[11px] text-slate-500">{totalCards} cartes au total</span>
      </div>
      <div className="space-y-2">
        {SCHEDULE.map((s) => (
          <div key={s.title} className={`rounded-2xl px-4 py-2.5 flex items-center justify-between ${s.color}`}>
            <div className="min-w-0">
              <p className="text-xs font-semibold truncate">{s.title}</p>
              <p className="text-[10px] opacity-80">{s.type}</p>
            </div>
            <div className="text-right shrink-0 pl-2">
              <p className="text-[11px] font-semibold">{s.time}</p>
              <p className="text-[10px] opacity-80">{s.cards} cartes</p>
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}
