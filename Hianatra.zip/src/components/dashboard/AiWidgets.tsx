"use client";

import { useState } from "react";
import { AreaChart, Area, ResponsiveContainer, XAxis, Tooltip } from "recharts";
import { CheckCircle2, Sparkles, Mic, Bell } from "lucide-react";
import { GlassCard, PROGRESS_BAR_GLOW } from "@/components/ui/GlassCard";
import { useGemini } from "@/hooks/useGemini";

const RETENTION = [
  { d: "Lun", v: 0.9 },
  { d: "Mar", v: 1.35 },
  { d: "Mer", v: 1.05 },
  { d: "Jeu", v: 0.55 },
  { d: "Ven", v: 0.75 },
  { d: "Sam", v: 1.15 },
  { d: "Dim", v: 1.3 },
];

export function StatsPanel({ cardsToday, masteredThisMonth }: { cardsToday: number; masteredThisMonth: number }) {
  return (
    <GlassCard dark className="p-4">
      <p className="text-xs text-slate-300 mb-1">Cartes aujourd&apos;hui</p>
      <p className="text-2xl font-bold text-white mb-3">{cardsToday}</p>
      <p className="text-xs text-slate-300 mb-1">Maîtrisées ce mois-ci</p>
      <p className="text-2xl font-bold text-white flex items-center gap-2">
        {masteredThisMonth} <CheckCircle2 size={16} className="text-emerald-400" />
      </p>
    </GlassCard>
  );
}

export function RetentionChart() {
  return (
    <GlassCard className="p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="font-semibold text-slate-800 text-sm">Rétention (SM-2)</p>
        <span className="text-[11px] text-slate-500">7 jours</span>
      </div>
      <div className="h-36">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={RETENTION}>
            <defs>
              <linearGradient id="ret" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#fb7185" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#fb7185" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="d" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ borderRadius: 12, fontSize: 11 }} />
            <Area type="monotone" dataKey="v" stroke="#fb7185" strokeWidth={2} fill="url(#ret)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </GlassCard>
  );
}

export function NextNotificationCard() {
  return (
    <GlassCard className="p-4">
      <p className="font-semibold text-slate-800 text-sm mb-3">Prochaine notification</p>
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center">
          <Bell size={14} className="text-emerald-600" />
        </div>
        <div>
          <p className="text-xs font-medium text-slate-700">Révision &quot;Anatomie&quot;</p>
          <p className="text-[11px] text-slate-500">Push prévu à 18:00</p>
        </div>
      </div>
      <div className={`h-1.5 mt-3 ${PROGRESS_BAR_GLOW}`} style={{ width: "70%" }} />
    </GlassCard>
  );
}

/** Assistant "ELI5" — appelle le prompt système via /api/gemini (mode: eli5) */
export function Eli5Widget() {
  const [concept, setConcept] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);
  const { loading, explainLikeImFive } = useGemini();

  async function handleAsk() {
    if (!concept.trim()) return;
    const result = await explainLikeImFive(concept);
    setAnswer(result?.text ?? "Impossible de générer une explication pour le moment.");
  }

  return (
    <GlassCard className="p-4">
      <p className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1">
        <Sparkles size={13} className="text-amber-500" /> Explique-moi comme à un enfant
      </p>
      <input
        value={concept}
        onChange={(e) => setConcept(e.target.value)}
        placeholder="ex : la thermodynamique…"
        className="w-full text-xs bg-white/60 rounded-xl px-3 py-2 outline-none placeholder:text-slate-400 mb-2"
      />
      <button
        onClick={handleAsk}
        disabled={loading}
        className="w-full text-xs font-medium bg-slate-900 text-white rounded-xl py-2 disabled:opacity-50"
      >
        {loading ? "Génération…" : "Demander à l'IA"}
      </button>
      {answer && <p className="text-[11px] text-slate-600 mt-2">{answer}</p>}
    </GlassCard>
  );
}

/** Bilan audio du soir — récupère un script motivant puis le lit via SpeechSynthesis (gratuit, offline) */
export function AudioDigestWidget({ studySummary }: { studySummary: string }) {
  const { loading, generateDailyDigest } = useGemini();

  async function play() {
    const result = await generateDailyDigest(studySummary);
    if (!result?.text) return;
    const utterance = new SpeechSynthesisUtterance(result.text);
    utterance.lang = "fr-FR";
    window.speechSynthesis.speak(utterance);
  }

  return (
    <GlassCard className="p-4 flex items-center gap-3">
      <button
        onClick={play}
        disabled={loading}
        className="w-10 h-10 rounded-2xl bg-slate-900 flex items-center justify-center shrink-0 disabled:opacity-50"
        aria-label="Écouter le bilan audio"
      >
        <Mic size={16} className="text-white" />
      </button>
      <div className="min-w-0">
        <p className="text-xs font-semibold text-slate-700">Bilan audio du soir</p>
        <p className="text-[11px] text-slate-500 truncate">
          {loading ? "Génération du script…" : "Écoute le résumé motivant de ta journée"}
        </p>
      </div>
    </GlassCard>
  );
}
