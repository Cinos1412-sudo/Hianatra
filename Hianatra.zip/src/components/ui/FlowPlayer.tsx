"use client";

import { useEffect, useRef, useState } from "react";
import { Play, Pause, Music2 } from "lucide-react";
import { AUDIO_TRACKS } from "@/utils/audioTracks";
import { GlassCard } from "./GlassCard";

/**
 * Lecteur audio "flux" (binaural, pluie, lo-fi) basé sur l'API HTML5 Audio native.
 * Utilisé pour l'ambiance sonore pendant les sessions de révision.
 */
export function FlowPlayer() {
  const [trackId, setTrackId] = useState(AUDIO_TRACKS[0].id);
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const track = AUDIO_TRACKS.find((t) => t.id === trackId) ?? AUDIO_TRACKS[0];

  useEffect(() => {
    audioRef.current = new Audio(track.url);
    audioRef.current.loop = true;
    if (playing) audioRef.current.play().catch(() => setPlaying(false));

    return () => {
      audioRef.current?.pause();
      audioRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trackId]);

  function toggle() {
    if (!audioRef.current) return;
    if (playing) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(() => {});
    }
    setPlaying(!playing);
  }

  return (
    <GlassCard className="p-4 flex items-center gap-3">
      <button
        onClick={toggle}
        className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center shrink-0"
        aria-label={playing ? "Mettre en pause" : "Lancer le son d'ambiance"}
      >
        {playing ? <Pause size={16} /> : <Play size={16} />}
      </button>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-semibold text-slate-700 flex items-center gap-1">
          <Music2 size={12} /> Ambiance sonore
        </p>
        <div className="flex gap-1 mt-1">
          {AUDIO_TRACKS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTrackId(t.id)}
              className={`text-[10px] px-2 py-1 rounded-full ${
                t.id === trackId ? "bg-slate-900 text-white" : "bg-white/60 text-slate-600"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>
    </GlassCard>
  );
}
