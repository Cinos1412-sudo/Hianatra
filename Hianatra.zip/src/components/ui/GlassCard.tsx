import { cn } from "@/lib/cn";
import type { ReactNode } from "react";

// Token réutilisable pour l'effet Liquid Glass Light, tel que défini dans le blueprint
export const LIQUID_GLASS_LIGHT =
  "bg-white/30 backdrop-blur-xl border border-white/40 shadow-sm shadow-slate-200/50 rounded-3xl transition-all duration-300";

// Token pour les barres de progression "On-Fire" (Neon glow discret)
export const PROGRESS_BAR_GLOW =
  "bg-gradient-to-r from-emerald-400 to-teal-500 shadow-[0_0_15px_rgba(52,211,153,0.4)] rounded-full";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  dark?: boolean;
}

export function GlassCard({ children, className, dark }: GlassCardProps) {
  return (
    <div
      className={cn(
        LIQUID_GLASS_LIGHT,
        dark && "!bg-slate-900 !border-slate-800 text-white",
        className
      )}
    >
      {children}
    </div>
  );
}
