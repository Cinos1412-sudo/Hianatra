# Learning App

Application d'apprentissage **offline-first** (Next.js 15+, TypeScript, Tailwind), construite selon le blueprint :
- Révision espacée (SM-2)
- Assistant IA (ELI5, génération de flashcards, bilan audio du soir) via un proxy Gemini sécurisé
- Bloc-notes avec croquis (OCR) et éditeur markdown
- Synchronisation IndexedDB (Dexie.js) → Supabase, déclenchée au retour du réseau
- Routeur d'affichage intelligent (vue mobile vs vue desktop)

## Démarrage

```bash
npm install
cp .env.example .env.local   # renseigne tes clés Supabase / Gemini / VAPID
npm run dev
```

Ouvre [http://localhost:3000](http://localhost:3000) — tu seras automatiquement redirigé vers
`/dashboard/web` ou `/dashboard/mobile` selon la largeur de ton écran.

## Structure

```
src/
├── app/
│   ├── layout.tsx              # PWA setup, styles globaux
│   ├── page.tsx                # Routeur d'affichage intelligent
│   ├── dashboard/
│   │   ├── mobile/page.tsx
│   │   └── web/page.tsx
│   └── api/
│       ├── gemini/route.ts     # Proxy Gemini (ELI5, flashcards, digest)
│       └── push/route.ts       # Web Push (rappels de révision)
├── components/
│   ├── ui/          (GlassCard, FlowPlayer)
│   ├── dashboard/   (QuickCalendar, ScheduleList, ActiveTracking, AiWidgets)
│   └── notebook/    (SketchCanvas, NoteEditor)
├── hooks/           (useNetwork, useOfflineStorage, useGemini)
└── utils/           (spacedRepetition.ts, audioTracks.ts)
```

## Points à finaliser avant mise en production

- Créer les tables Supabase (`notes`) correspondant au schéma Dexie et régler les policies RLS.
- Générer de vraies clés VAPID (`npx web-push generate-vapid-keys`) pour les notifications.
- Héberger tes propres boucles audio CC0 et mettre à jour `utils/audioTracks.ts`.
- Ajouter les icônes PWA dans `public/` et les référencer dans `manifest.json`.
- Le composant `SketchCanvas` exporte l'image en base64 — pense à compresser avant l'envoi à Gemini Vision si les croquis sont volumineux.
