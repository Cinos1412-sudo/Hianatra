# Study Notebook — Liquid Glass (Next.js)

Application de prise de notes tactile avec assistant IA "ELI5", flashcards
en répétition espacée (SM-2), planificateur hebdomadaire, lecteur Lo-Fi et
synchronisation Offline-First ↔ Cloud, dans le design **Glassmorphism
"Liquid Glass"** (bento grid desktop / vue une-main mobile).

## 1. Installer les dépendances

```bash
npm install
```

## 2. 🔑 Ajouter tes clés API (À FAIRE DE TON CÔTÉ)

Toutes les clés sont laissées **vides intentionnellement**. L'app tourne
très bien sans elles (mode 100% local / hors-ligne) ; il te suffit de les
ajouter quand tu es prêt à activer le Cloud Sync et l'assistant IA.

1. Copie le fichier d'exemple :
   ```bash
   cp .env.local.example .env.local
   ```
2. Ouvre `.env.local` et remplis les 3 valeurs :

   | Variable | Où la trouver | Utilisée dans |
   |---|---|---|
   | `NEXT_PUBLIC_SUPABASE_URL` | Supabase Dashboard → Project Settings → API | `src/lib/supabaseClient.ts` |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase Dashboard → Project Settings → API | `src/lib/supabaseClient.ts` |
   | `GEMINI_API_KEY` | https://aistudio.google.com/app/apikey | `src/app/api/gemini/route.ts` (serveur uniquement) |

   Tant que `GEMINI_API_KEY` est vide, le bouton "Explique-moi (ELI5)"
   répond simplement qu'il manque une clé — l'app ne plante jamais.

   Tant que les clés Supabase sont vides, `isSupabaseConfigured` reste
   `false` et le hook `useBackgroundSync` ne tente aucune synchronisation :
   toutes les données restent stockées localement (IndexedDB via Dexie).

## 3. (Optionnel) Créer les tables Supabase

Si tu actives le Cloud Sync, crée ces 3 tables dans l'éditeur SQL Supabase :

```sql
create table notes (
  uuid uuid primary key,
  title text,
  content text,
  drawing_base64 text,
  color text,
  created_at timestamptz,
  updated_at timestamptz
);

create table flashcards (
  uuid uuid primary key,
  note_id uuid,
  question text,
  answer text,
  repetitions int,
  interval int,
  ease_factor float8,
  due_date timestamptz
);

create table planner_blocks (
  uuid uuid primary key,
  title text,
  subtitle text,
  day date,
  start_hour int,
  end_hour int,
  color text
);
```

> ⚠️ Adapte `src/hooks/useBackgroundSync.ts` si tu ajoutes une colonne
> `user_id` pour isoler les données par utilisateur (recommandé avec
> Supabase Auth en production).

## 4. (Optionnel) Ajouter de la musique Lo-Fi

Dépose des fichiers `.mp3` libres de droits dans `public/audio/` et
mets à jour la liste `TRACKS` dans `src/components/ui/FlowPlayer.tsx`.

## 5. Lancer en développement

```bash
npm run dev
```

Ouvre [http://localhost:3000](http://localhost:3000) — redimensionne la
fenêtre sous 768px de large pour basculer sur la vue mobile une-main.

## Structure du projet

```
src/
  app/
    page.tsx                 # Dispatcher responsive (mobile / bento web)
    layout.tsx
    api/gemini/route.ts       # Assistant IA ELI5 (clé serveur)
  components/
    ui/
      GlassCard.tsx            # Enveloppe Liquid Glass réutilisable
      FlowPlayer.tsx           # Lecteur Lo-Fi
      Sidebar.tsx              # Navigation web
    notebook/
      NoteEditor.tsx           # Bloc-notes tactile + ELI5 + auto-save
      generateFlashcards.ts    # Génération silencieuse de flashcards
    dashboard/
      AdvancedDashboardMobile.tsx
      AdvancedDashboardWeb.tsx
      AdvancedWeeklyPlanner.tsx
      FlashcardQuiz.tsx        # Moteur SM-2
      StatsPanel.tsx
      AppHeader.tsx
  hooks/
    useBackgroundSync.ts       # Offline-first <-> Cloud Sync
  lib/
    supabaseClient.ts
  utils/
    db.ts                      # Dexie / IndexedDB
    spacedRepetition.ts         # Algorithme SM-2
  types/
    index.ts
```

## Design system "Liquid Glass"

Classe de base des cartes (voir `globals.css` / `GlassCard.tsx`) :

```
bg-white/75 backdrop-blur-lg border border-white/45 shadow-sm shadow-slate-200/50 rounded-3xl
```

Palette (voir `tailwind.config.ts`) : fond crème `#F3EFE9` avec halos
dégradés pêche/rose, cartes accent orange `#F9834A`, jaune `#F4B740`,
rose `#FB7B86`, bleu `#42C6F0`, vert d'eau `#33D6A6`, et cellules
sombres `#12131A` pour les statistiques mises en avant — fidèle aux
deux mockups fournis.
