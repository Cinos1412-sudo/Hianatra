import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#12131A",
        glass: {
          DEFAULT: "rgba(255,255,255,0.75)",
          border: "rgba(255,255,255,0.45)",
        },
        accent: {
          orange: "#F9834A",
          yellow: "#F4B740",
          pink: "#FB7B86",
          blue: "#42C6F0",
          teal: "#33D6A6",
        },
        surface: {
          cream: "#F3EFE9",
          peach: "#F7E4D6",
          blush: "#FBD9DF",
          mint: "#DCF6EB",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      borderRadius: {
        "4xl": "2rem",
      },
      backdropBlur: {
        xl: "20px",
      },
      boxShadow: {
        glass: "0 8px 32px rgba(148, 130, 110, 0.12)",
      },
    },
  },
  plugins: [],
};

export default config;
