import { NextRequest, NextResponse } from "next/server";

/**
 * Route API — Assistant IA "ELI5" (Explain Like I'm 5).
 *
 * Le front-end (bouton flottant dans NoteEditor.tsx) envoie le texte
 * sélectionné/écrit dans la note, et reçoit une explication simplifiée.
 *
 * ⚠️ La clé GEMINI_API_KEY doit être définie dans .env.local
 * (voir .env.local.example). Elle n'est utilisée que côté serveur,
 * jamais exposée au navigateur.
 */

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_ENDPOINT =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

export async function POST(req: NextRequest) {
  try {
    const { text } = (await req.json()) as { text?: string };

    if (!text || !text.trim()) {
      return NextResponse.json(
        { error: "Aucun texte fourni à expliquer." },
        { status: 400 }
      );
    }

    if (!GEMINI_API_KEY) {
      return NextResponse.json(
        {
          error:
            "GEMINI_API_KEY manquante. Ajoute ta clé dans .env.local (voir .env.local.example) pour activer l'assistant ELI5.",
        },
        { status: 501 }
      );
    }

    const prompt = `Explique le concept suivant comme si j'avais 5 ans, en français, en 3 phrases maximum, avec une analogie simple:\n\n"""${text}"""`;

    const response = await fetch(`${GEMINI_ENDPOINT}?key=${GEMINI_API_KEY}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
      }),
    });

    if (!response.ok) {
      const errBody = await response.text();
      return NextResponse.json(
        { error: `Erreur Gemini (${response.status}): ${errBody}` },
        { status: 502 }
      );
    }

    const data = await response.json();
    const explanation: string =
      data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() ??
      "Désolé, je n'ai pas pu générer d'explication.";

    return NextResponse.json({ explanation });
  } catch (error) {
    console.error("Erreur route /api/gemini:", error);
    return NextResponse.json(
      { error: "Erreur interne lors de l'appel à l'assistant IA." },
      { status: 500 }
    );
  }
}
