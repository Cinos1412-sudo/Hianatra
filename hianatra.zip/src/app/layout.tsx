import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Study Notebook — Liquid Glass",
  description:
    "Bloc-notes tactile, assistant IA ELI5, flashcards SM-2 et planificateur hebdo, en Glassmorphism Liquid Glass.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#F3EFE9",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body>
        <div className="liquid-backdrop" aria-hidden="true" />
        {children}
      </body>
    </html>
  );
}
