"use client";

import { useEffect, useState } from "react";
import AdvancedDashboardMobile from "@/components/dashboard/AdvancedDashboardMobile";
import AdvancedDashboardWeb from "@/components/dashboard/AdvancedDashboardWeb";
import { useBackgroundSync } from "@/hooks/useBackgroundSync";

/**
 * src/app/page.tsx — Layout réactif fondateur.
 *
 * Orchestre l'expérience selon la taille de l'écran : dispatcher entre la
 * vue mobile épurée à une main et la grille Bento Desktop. Initialise le
 * hook de synchronisation globale (Offline-First + Cloud Sync).
 */
export default function MainAppPage() {
  const { status } = useBackgroundSync();
  const [isDesktop, setIsDesktop] = useState<boolean | null>(null);

  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    setIsDesktop(mq.matches);
    const handler = (e: MediaQueryListEvent) => setIsDesktop(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  // Évite un flash de mise en page incorrecte le temps de détecter la taille d'écran
  if (isDesktop === null) return null;

  const userName = "Cécillia Funi";

  return isDesktop ? (
    <AdvancedDashboardWeb userName={userName} status={status} />
  ) : (
    <AdvancedDashboardMobile userName={userName} status={status} />
  );
}
