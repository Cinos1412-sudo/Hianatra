/**
 * Logique mathématique de répétition espacée (SM-2)
 *
 * L'algorithme calcule l'intervalle idéal (I) et le facteur de réplication
 * (EF) basé sur une évaluation de qualité (q) allant de 0 à 5.
 * Dans l'interface, q est simplifié en 3 boutons : Facile = 5, Moyen = 3, Dur = 1.
 *
 * Formule du facteur de facilité :
 * EF' = EF + (0.1 - (5 - q) × (0.08 + (5 - q) × 0.02))
 */

export interface SM2State {
  repetitions: number;
  interval: number;
  easeFactor: number;
}

export const DEFAULT_SM2_STATE: SM2State = {
  repetitions: 0,
  interval: 0,
  easeFactor: 2.5,
};

export type QuizQuality = "hard" | "medium" | "easy";

export const QUALITY_SCORE: Record<QuizQuality, number> = {
  hard: 1,
  medium: 3,
  easy: 5,
};

export function calculateSM2(quality: number, prevState: SM2State): SM2State {
  let { repetitions, interval, easeFactor } = prevState;

  if (quality >= 3) {
    if (repetitions === 0) {
      interval = 1;
    } else if (repetitions === 1) {
      interval = 6;
    } else {
      interval = Math.round(interval * easeFactor);
    }
    repetitions++;
  } else {
    repetitions = 0;
    interval = 1;
  }

  easeFactor = easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
  if (easeFactor < 1.3) easeFactor = 1.3;

  return { repetitions, interval, easeFactor };
}

/** Calcule la prochaine date d'échéance (ISO) à partir d'un intervalle en jours. */
export function nextDueDate(interval: number, from: Date = new Date()): string {
  const due = new Date(from);
  due.setDate(due.getDate() + interval);
  return due.toISOString();
}
