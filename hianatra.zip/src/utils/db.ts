import Dexie, { type Table } from "dexie";
import type { Note, Flashcard, PlannerBlock } from "@/types";

/**
 * Base de données locale (Offline-First).
 * Toute écriture (note, dessin, carte, bloc planning) est immédiatement
 * persistée ici. Aucune opération ne dépend du réseau : le hook
 * useBackgroundSync se charge ensuite, en tâche de fond, de pousser les
 * changements vers Supabase quand la connexion est disponible.
 */
class StudyDB extends Dexie {
  notes!: Table<Note, number>;
  flashcards!: Table<Flashcard, number>;
  plannerBlocks!: Table<PlannerBlock, number>;

  constructor() {
    super("studyAppDB");
    this.version(1).stores({
      notes: "++id, uuid, updatedAt, synced",
      flashcards: "++id, uuid, dueDate, synced",
      plannerBlocks: "++id, uuid, day, synced",
    });
  }
}

// En SSR (Next.js) `window` n'existe pas : on garde une instance unique,
// créée seulement côté client.
export const db = typeof window !== "undefined" ? new StudyDB() : (null as unknown as StudyDB);

export async function getUnsyncedCount(): Promise<number> {
  if (!db) return 0;
  const [notes, cards, blocks] = await Promise.all([
    db.notes.filter((n) => !n.synced).count(),
    db.flashcards.filter((c) => !c.synced).count(),
    db.plannerBlocks.filter((b) => !b.synced).count(),
  ]);
  return notes + cards + blocks;
}
