"use client";

import { useRef, useState, useEffect, useCallback } from "react";
import { Sparkles, Pen, Type, Save, Loader2 } from "lucide-react";
import GlassCard from "@/components/ui/GlassCard";
import { db } from "@/utils/db";
import type { Note } from "@/types";
import { generateFlashcardsFromText } from "./generateFlashcards";

interface NoteEditorProps {
  className?: string;
}

/**
 * Bloc-notes tactile.
 * - Mobile : onglet dédié "Éditeur" (barre basse).
 * - Web : cellule principale basse-gauche de la grille Bento.
 *
 * Fonctionnalités intégrées :
 * 2. Bloc-notes tactile (texte + dessin, Canvas)
 * 3. Assistant IA ELI5 (bouton flottant)
 * 4. Générateur de flashcards (déclenché silencieusement en tâche de fond)
 * 8. Offline-First : chaque sauvegarde part directement dans Dexie/IndexedDB
 */
export default function NoteEditor({ className }: NoteEditorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mode, setMode] = useState<"text" | "draw">("text");
  const [title, setTitle] = useState("Chapitre 4 — Thermodynamique");
  const [content, setContent] = useState("");
  const [isDrawing, setIsDrawing] = useState(false);
  const [eli5Loading, setEli5Loading] = useState(false);
  const [eli5Answer, setEli5Answer] = useState<string | null>(null);
  const [saveState, setSaveState] = useState<"idle" | "saved">("idle");

  // --- Canvas tactile : dessin léger converti en Base64 (offline-safe) ---
  const getPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current!.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const startDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (mode !== "draw") return;
    setIsDrawing(true);
    const ctx = canvasRef.current?.getContext("2d");
    const { x, y } = getPos(e);
    ctx?.beginPath();
    ctx?.moveTo(x, y);
  };

  const draw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing || mode !== "draw") return;
    const ctx = canvasRef.current?.getContext("2d");
    const { x, y } = getPos(e);
    if (!ctx) return;
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#12131A";
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDraw = () => setIsDrawing(false);

  // --- Sauvegarde offline-first (Dexie) ---
  const saveNote = useCallback(async () => {
    if (!db) return;
    const drawingBase64 = canvasRef.current?.toDataURL("image/png") ?? null;
    const note: Note = {
      uuid: crypto.randomUUID(),
      title,
      content,
      drawingBase64,
      color: "blue",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      synced: false,
    };
    await db.notes.add(note);
    setSaveState("saved");
    setTimeout(() => setSaveState("idle"), 1500);

    // 4. Générateur de flashcards — déclenché silencieusement en tâche de
    // fond, sans bloquer l'UI ni attendre le réseau.
    if (content.trim().length > 40) {
      generateFlashcardsFromText(content).catch(() => {
        /* échec silencieux : l'utilisateur n'est jamais bloqué */
      });
    }
  }, [title, content]);

  // Auto-save léger (debounce) pour ne jamais perdre de contenu hors-ligne
  useEffect(() => {
    const t = setTimeout(() => {
      if (content.trim().length > 0) saveNote();
    }, 4000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [content]);

  // --- Assistant IA ELI5 ---
  const askEli5 = async () => {
    const selection = window.getSelection()?.toString();
    const source = selection && selection.length > 0 ? selection : content;
    if (!source.trim()) return;

    setEli5Loading(true);
    setEli5Answer(null);
    try {
      const res = await fetch("/api/gemini", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: source }),
      });
      const data = await res.json();
      setEli5Answer(data.explanation ?? data.error ?? "Réponse indisponible.");
    } catch {
      setEli5Answer(
        "Impossible de contacter l'assistant IA (hors-ligne ou clé API absente)."
      );
    } finally {
      setEli5Loading(false);
    }
  };

  return (
    <GlassCard className={className} as="section">
      <div className="mb-3 flex items-center justify-between gap-2">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full bg-transparent font-display text-lg font-semibold text-ink outline-none"
          aria-label="Titre de la note"
        />
        <div className="flex shrink-0 items-center gap-1 rounded-full bg-ink/5 p-1">
          <button
            onClick={() => setMode("text")}
            aria-pressed={mode === "text"}
            className={`grid h-8 w-8 place-items-center rounded-full ${
              mode === "text" ? "bg-ink text-white" : "text-ink/50"
            }`}
            aria-label="Mode texte"
          >
            <Type size={14} />
          </button>
          <button
            onClick={() => setMode("draw")}
            aria-pressed={mode === "draw"}
            className={`grid h-8 w-8 place-items-center rounded-full ${
              mode === "draw" ? "bg-ink text-white" : "text-ink/50"
            }`}
            aria-label="Mode dessin"
          >
            <Pen size={14} />
          </button>
        </div>
      </div>

      {mode === "text" ? (
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Écris ou colle ton cours ici…"
          rows={8}
          className="thin-scrollbar w-full resize-none rounded-2xl bg-white/40 p-4 text-sm text-ink outline-none placeholder:text-ink/30"
        />
      ) : (
        <canvas
          ref={canvasRef}
          width={480}
          height={220}
          onPointerDown={startDraw}
          onPointerMove={draw}
          onPointerUp={stopDraw}
          onPointerLeave={stopDraw}
          className="w-full touch-none rounded-2xl bg-white/40"
          aria-label="Zone de dessin tactile"
        />
      )}

      {/* Zone accessible au pouce (tiers inférieur) : IA + sauvegarde */}
      <div className="mt-4 flex items-center justify-between">
        <button
          onClick={askEli5}
          disabled={eli5Loading}
          className="flex items-center gap-2 rounded-full bg-accent-blue/90 px-4 py-2 text-sm font-medium text-white shadow-sm disabled:opacity-60"
        >
          {eli5Loading ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
          Explique-moi (ELI5)
        </button>
        <button
          onClick={saveNote}
          className="flex items-center gap-2 rounded-full bg-ink px-4 py-2 text-sm font-medium text-white"
        >
          <Save size={14} />
          {saveState === "saved" ? "Enregistré ✓" : "Enregistrer"}
        </button>
      </div>

      {eli5Answer && (
        <div className="mt-3 rounded-2xl bg-accent-blue/10 p-4 text-sm text-ink/80">
          {eli5Answer}
        </div>
      )}
    </GlassCard>
  );
}
