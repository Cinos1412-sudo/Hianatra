import { db } from "@/utils/db";
import { DEFAULT_SM2_STATE, nextDueDate } from "@/utils/spacedRepetition";
import type { Flashcard } from "@/types";

/**
 * Générateur de flashcards (fonctionnalité 4).
 * Se déclenche silencieusement en tâche de fond après l'enregistrement
 * d'une note (mobile ET web) : aucune UI de chargement, aucun blocage.
 *
 * Stratégie par défaut (hors-ligne, sans coût API) : découpe le texte en
 * phrases et transforme chacune en carte "question / réponse" simple.
 * Remplace `buildQuestionAnswerPairs` par un appel à /api/gemini si tu
 * préfères des flashcards générées par IA (coûte un appel API par note).
 */
function buildQuestionAnswerPairs(text: string): { question: string; answer: string }[] {
  const sentences = text
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 15);

  return sentences.slice(0, 5).map((sentence, i) => ({
    question: `Complète / explique le point ${i + 1} du chapitre :`,
    answer: sentence,
  }));
}

export async function generateFlashcardsFromText(noteContent: string, noteId?: string) {
  if (!db) return;
  const pairs = buildQuestionAnswerPairs(noteContent);
  if (pairs.length === 0) return;

  const cards: Flashcard[] = pairs.map(({ question, answer }) => ({
    uuid: crypto.randomUUID(),
    noteId,
    question,
    answer,
    repetitions: DEFAULT_SM2_STATE.repetitions,
    interval: DEFAULT_SM2_STATE.interval,
    easeFactor: DEFAULT_SM2_STATE.easeFactor,
    dueDate: nextDueDate(0),
    synced: false,
  }));

  await db.flashcards.bulkAdd(cards);
}
