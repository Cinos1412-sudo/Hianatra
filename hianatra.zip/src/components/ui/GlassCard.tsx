import clsx from "clsx";
import type { HTMLAttributes } from "react";

interface GlassCardProps extends HTMLAttributes<HTMLDivElement> {
  as?: "div" | "section" | "article";
  padded?: boolean;
}

/**
 * Enveloppe structurelle Liquid Glass utilisée par tous les blocs de
 * l'application (mobile : onglets empilés / web : cellules de la grille
 * Bento).
 *
 * Spéc. CSS (cf. document d'architecture) :
 * bg-white/75 backdrop-blur-lg border border-white/45 shadow-sm
 * shadow-slate-200/50 rounded-3xl
 */
export default function GlassCard({
  as = "div",
  padded = true,
  className,
  children,
  ...rest
}: GlassCardProps) {
  const Component = as;
  return (
    <Component
      className={clsx(
        "glass-surface rounded-3xl",
        padded && "p-5",
        className
      )}
      {...rest}
    >
      {children}
    </Component>
  );
}
