"use client";

import { useRef, useState } from "react";
import { Play, Pause, Music2 } from "lucide-react";
import clsx from "clsx";

const TRACKS = [
  { title: "Focus Rain", src: "/audio/focus-rain.mp3" },
  { title: "Deep Study", src: "/audio/deep-study.mp3" },
  { title: "Night Coffee", src: "/audio/night-coffee.mp3" },
];

interface FlowPlayerProps {
  /** "compact" = icône header mobile · "full" = widget header web */
  variant?: "compact" | "full";
}

/**
 * Lecteur Lo-Fi "FlowPlayer".
 * ⚠️ Place tes propres fichiers audio (libres de droits) dans /public/audio/
 * pour remplacer les pistes de démonstration ci-dessus.
 */
export default function FlowPlayer({ variant = "full" }: FlowPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [trackIndex, setTrackIndex] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  const toggle = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(() => {
        // Fichier audio absent en démo : on met simplement à jour l'état
      });
    }
    setIsPlaying(!isPlaying);
  };

  const track = TRACKS[trackIndex];

  if (variant === "compact") {
    return (
      <button
        onClick={toggle}
        aria-label={isPlaying ? "Mettre en pause la musique" : "Lancer la musique Lo-Fi"}
        className="grid h-10 w-10 place-items-center rounded-full glass-surface text-ink"
      >
        {isPlaying ? <Pause size={16} /> : <Music2 size={16} />}
        <audio ref={audioRef} src={track.src} loop />
      </button>
    );
  }

  return (
    <div className="flex items-center gap-3 rounded-full glass-surface px-4 py-2">
      <button
        onClick={toggle}
        aria-label={isPlaying ? "Pause" : "Lecture"}
        className={clsx(
          "grid h-8 w-8 place-items-center rounded-full text-white transition-colors",
          isPlaying ? "bg-accent-teal" : "bg-ink"
        )}
      >
        {isPlaying ? <Pause size={14} /> : <Play size={14} />}
      </button>
      <div className="text-xs leading-tight">
        <p className="font-medium text-ink">{track.title}</p>
        <p className="text-ink/50">Lo-Fi · Focus</p>
      </div>
      <button
        onClick={() => setTrackIndex((i) => (i + 1) % TRACKS.length)}
        className="text-xs text-ink/40 hover:text-ink"
      >
        suivant
      </button>
      <audio ref={audioRef} src={track.src} loop />
    </div>
  );
}
