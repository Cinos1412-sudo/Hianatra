"use client";

import { useState } from "react";
import { Home, NotebookPen, CalendarDays, BrainCircuit, BarChart3, Grid2x2, Settings } from "lucide-react";
import clsx from "clsx";

const ITEMS = [
  { key: "home", icon: Home, label: "Accueil" },
  { key: "notes", icon: NotebookPen, label: "Notes" },
  { key: "planner", icon: CalendarDays, label: "Planning" },
  { key: "quiz", icon: BrainCircuit, label: "Quiz SM-2" },
  { key: "stats", icon: BarChart3, label: "Statistiques" },
  { key: "grid", icon: Grid2x2, label: "Vue Bento" },
];

export default function Sidebar() {
  const [active, setActive] = useState("home");

  return (
    <nav
      aria-label="Navigation principale"
      className="flex h-full w-20 flex-col items-center justify-between rounded-4xl bg-ink py-6"
    >
      <div className="flex flex-col items-center gap-3">
        {ITEMS.map(({ key, icon: Icon, label }) => (
          <button
            key={key}
            onClick={() => setActive(key)}
            aria-label={label}
            aria-current={active === key}
            className={clsx(
              "grid h-11 w-11 place-items-center rounded-2xl transition-colors",
              active === key ? "bg-white text-ink" : "text-white/40 hover:text-white/70"
            )}
          >
            <Icon size={18} />
          </button>
        ))}
      </div>
      <button aria-label="Réglages" className="grid h-11 w-11 place-items-center rounded-2xl text-white/40 hover:text-white/70">
        <Settings size={18} />
      </button>
    </nav>
  );
}
