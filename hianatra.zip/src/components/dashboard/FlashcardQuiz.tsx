"use client";

import { useEffect, useState, useCallback } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { BrainCircuit } from "lucide-react";
import GlassCard from "@/components/ui/GlassCard";
import { db } from "@/utils/db";
import {
  calculateSM2,
  nextDueDate,
  QUALITY_SCORE,
  type QuizQuality,
} from "@/utils/spacedRepetition";

interface FlashcardQuizProps {
  className?: string;
}

/**
 * Moteur SM-2 (Quiz).
 * - Mobile : onglet dédié "Quiz SM-2" (barre basse).
 * - Web : colonne latérale droite (section basse).
 */
export default function FlashcardQuiz({ className }: FlashcardQuizProps) {
  const dueCards = useLiveQuery(async () => {
    if (!db) return [];
    const now = new Date().toISOString();
    return db.flashcards.filter((c) => c.dueDate <= now).toArray();
  }, []);

  const [revealed, setRevealed] = useState(false);
  const current = dueCards?.[0];

  useEffect(() => setRevealed(false), [current?.uuid]);

  const answer = useCallback(
    async (quality: QuizQuality) => {
      if (!db || !current) return;
      const q = QUALITY_SCORE[quality];
      const next = calculateSM2(q, {
        repetitions: current.repetitions,
        interval: current.interval,
        easeFactor: current.easeFactor,
      });
      await db.flashcards.update(current.id!, {
        repetitions: next.repetitions,
        interval: next.interval,
        easeFactor: next.easeFactor,
        dueDate: nextDueDate(next.interval),
        synced: false,
      });
      setRevealed(false);
    },
    [current]
  );

  return (
    <GlassCard className={className}>
      <div className="mb-3 flex items-center gap-2">
        <BrainCircuit size={18} className="text-accent-pink" />
        <h3 className="font-display text-base font-semibold text-ink">Quiz SM-2</h3>
        <span className="ml-auto rounded-full bg-accent-pink/15 px-2.5 py-0.5 text-xs font-medium text-accent-pink">
          {dueCards?.length ?? 0} à réviser
        </span>
      </div>

      {!current ? (
        <p className="rounded-2xl bg-white/40 p-4 text-sm text-ink/50">
          Aucune carte à réviser pour le moment — reviens plus tard, ou
          ajoute du contenu dans une note pour en générer.
        </p>
      ) : (
        <div className="space-y-3">
          <div className="rounded-2xl bg-white/50 p-4">
            <p className="text-sm font-medium text-ink">{current.question}</p>
            {revealed && (
              <p className="mt-2 border-t border-ink/10 pt-2 text-sm text-ink/70">
                {current.answer}
              </p>
            )}
          </div>

          {!revealed ? (
            <button
              onClick={() => setRevealed(true)}
              className="w-full rounded-full bg-ink py-2.5 text-sm font-medium text-white"
            >
              Afficher la réponse
            </button>
          ) : (
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => answer("hard")}
                className="rounded-full bg-accent-pink/90 py-2.5 text-sm font-medium text-white"
              >
                Dur
              </button>
              <button
                onClick={() => answer("medium")}
                className="rounded-full bg-accent-yellow/90 py-2.5 text-sm font-medium text-white"
              >
                Moyen
              </button>
              <button
                onClick={() => answer("easy")}
                className="rounded-full bg-accent-teal/90 py-2.5 text-sm font-medium text-white"
              >
                Facile
              </button>
            </div>
          )}
        </div>
      )}
    </GlassCard>
  );
}
