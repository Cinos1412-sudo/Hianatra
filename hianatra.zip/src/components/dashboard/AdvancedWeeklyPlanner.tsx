"use client";

import { useMemo, useState } from "react";
import clsx from "clsx";
import GlassCard from "@/components/ui/GlassCard";
import type { PlannerBlock } from "@/types";

const COLOR_MAP: Record<PlannerBlock["color"], string> = {
  orange: "bg-accent-orange text-white",
  yellow: "bg-accent-yellow text-white",
  pink: "bg-accent-pink text-white",
  blue: "bg-accent-blue text-white",
  teal: "bg-accent-teal text-white",
};

const DEMO_BLOCKS: Omit<PlannerBlock, "uuid" | "synced">[] = [
  { title: "Révision — Thermo", subtitle: "Chapitre 4", day: "mon", startHour: 8, endHour: 9, color: "orange" },
  { title: "Quiz SM-2", subtitle: "12 cartes dues", day: "mon", startHour: 10, endHour: 11, color: "yellow" },
  { title: "Note manuscrite", subtitle: "Cours d'histoire", day: "tue", startHour: 9, endHour: 10, color: "pink" },
  { title: "Session Lo-Fi", subtitle: "Deep focus", day: "wed", startHour: 14, endHour: 16, color: "blue" },
  { title: "Relecture flashcards", subtitle: "Bio cellulaire", day: "thu", startHour: 11, endHour: 12, color: "teal" },
];

const DAYS = [
  { key: "mon", label: "Lun" },
  { key: "tue", label: "Mar" },
  { key: "wed", label: "Mer" },
  { key: "thu", label: "Jeu" },
  { key: "fri", label: "Ven" },
  { key: "sat", label: "Sam" },
  { key: "sun", label: "Dim" },
];

interface AdvancedWeeklyPlannerProps {
  className?: string;
  compact?: boolean;
}

/**
 * Planificateur Hebdo.
 * - Mobile : ligne horizontale 7 jours sous le profil.
 * - Web : widget de contrôle central supérieur.
 */
export default function AdvancedWeeklyPlanner({
  className,
  compact = false,
}: AdvancedWeeklyPlannerProps) {
  const [activeDay, setActiveDay] = useState("mon");

  const blocksForDay = useMemo(
    () => DEMO_BLOCKS.filter((b) => b.day === activeDay),
    [activeDay]
  );

  return (
    <GlassCard className={className}>
      <div className="mb-4 flex items-center justify-between">
        <h3 className="font-display text-base font-semibold text-ink">
          Planificateur Hebdo
        </h3>
        <span className="text-xs text-ink/40">Juillet 2026</span>
      </div>

      <div className="flex gap-2 overflow-x-auto thin-scrollbar pb-1">
        {DAYS.map((d) => (
          <button
            key={d.key}
            onClick={() => setActiveDay(d.key)}
            className={clsx(
              "flex min-w-[52px] flex-col items-center rounded-2xl px-3 py-2 text-xs font-medium transition-colors",
              activeDay === d.key ? "bg-ink text-white" : "bg-white/40 text-ink/60"
            )}
          >
            {d.label}
          </button>
        ))}
      </div>

      {!compact && (
        <div className="mt-4 space-y-2">
          {blocksForDay.length === 0 ? (
            <p className="rounded-2xl bg-white/40 p-3 text-sm text-ink/40">
              Rien de prévu — profite-en pour ajouter une session.
            </p>
          ) : (
            blocksForDay.map((b, i) => (
              <div
                key={i}
                className={clsx(
                  "flex items-center justify-between rounded-2xl px-4 py-3",
                  COLOR_MAP[b.color]
                )}
              >
                <div>
                  <p className="text-sm font-semibold">{b.title}</p>
                  {b.subtitle && <p className="text-xs opacity-80">{b.subtitle}</p>}
                </div>
                <span className="text-xs font-medium opacity-90">
                  {b.startHour}h–{b.endHour}h
                </span>
              </div>
            ))
          )}
        </div>
      )}
    </GlassCard>
  );
}
