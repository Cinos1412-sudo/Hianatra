"use client";

import { useState } from "react";
import { Home, CalendarDays, Bell, Settings } from "lucide-react";
import clsx from "clsx";
import GlassCard from "@/components/ui/GlassCard";
import AppHeader from "@/components/dashboard/AppHeader";
import AdvancedWeeklyPlanner from "@/components/dashboard/AdvancedWeeklyPlanner";
import NoteEditor from "@/components/notebook/NoteEditor";
import FlashcardQuiz from "@/components/dashboard/FlashcardQuiz";
import StatsPanel from "@/components/dashboard/StatsPanel";
import type { SyncStatus } from "@/types";

interface AdvancedDashboardMobileProps {
  userName: string;
  status: SyncStatus;
}

const TABS = [
  { key: "home", label: "Accueil", icon: Home },
  { key: "planning", label: "Planning", icon: CalendarDays },
  { key: "quiz", label: "Quiz", icon: Bell },
  { key: "settings", label: "Réglages", icon: Settings },
] as const;

/**
 * Intégration mobile : prise en main à une main. Toutes les commandes
 * d'enregistrement, d'IA et d'évaluation SM-2 restent dans le tiers
 * inférieur de l'écran (cf. NoteEditor / FlashcardQuiz), directement
 * accessibles au pouce. Navigation par barre basse (4 onglets).
 */
export default function AdvancedDashboardMobile({ userName, status }: AdvancedDashboardMobileProps) {
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("home");

  return (
    <div className="mx-auto flex h-screen max-w-md flex-col gap-4 p-4 pb-24">
      <AppHeader userName={userName} status={status} variant="mobile" />

      <div className="flex-1 space-y-4 overflow-y-auto thin-scrollbar">
        {tab === "home" && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <GlassCard className="!bg-accent-orange text-white" padded>
                <p className="text-xs text-white/70">Notes actives</p>
                <p className="mt-1 font-display text-2xl font-bold">12</p>
              </GlassCard>
              <GlassCard className="!bg-accent-yellow text-white" padded>
                <p className="text-xs text-white/70">Cartes dues</p>
                <p className="mt-1 font-display text-2xl font-bold">8</p>
              </GlassCard>
            </div>
            <NoteEditor />
          </>
        )}

        {tab === "planning" && <AdvancedWeeklyPlanner />}

        {tab === "quiz" && <FlashcardQuiz />}

        {tab === "settings" && <StatsPanel variant="mobile" />}
      </div>

      {/* Barre de navigation basse — accessible au pouce */}
      <nav
        aria-label="Navigation"
        className="fixed inset-x-4 bottom-4 mx-auto flex max-w-md items-center justify-between rounded-3xl glass-surface px-6 py-3"
      >
        {TABS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            aria-label={label}
            aria-current={tab === key}
            className={clsx(
              "grid h-10 w-10 place-items-center rounded-2xl transition-colors",
              tab === key ? "bg-ink text-white" : "text-ink/40"
            )}
          >
            <Icon size={18} />
          </button>
        ))}
      </nav>
    </div>
  );
}
