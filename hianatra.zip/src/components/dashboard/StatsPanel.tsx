"use client";

import { LineChart, Line, ResponsiveContainer } from "recharts";
import GlassCard from "@/components/ui/GlassCard";
import clsx from "clsx";

const RETENTION_DATA = [
  { day: "Lun", value: 12 },
  { day: "Mar", value: 18 },
  { day: "Mer", value: 9 },
  { day: "Jeu", value: 22 },
  { day: "Ven", value: 15 },
  { day: "Sam", value: 26 },
  { day: "Dim", value: 20 },
];

const FOCUS_BARS = [
  { label: "2 juil", value: 40, color: "bg-accent-orange" },
  { label: "3 juil", value: 15, color: "bg-ink/10" },
  { label: "4 juil", value: 85, color: "bg-accent-blue", active: true },
  { label: "5 juil", value: 55, color: "bg-ink/10" },
  { label: "6 juil", value: 65, color: "bg-accent-teal" },
];

interface StatsPanelProps {
  className?: string;
  variant?: "mobile" | "web";
}

/**
 * Panneau "Statistic info" + "Time spends" (cf. mockup) :
 * tâches du jour, cartes complétées ce mois, temps de focus quotidien
 * et rétention de mémorisation sur 7 jours (cartes SM-2 réussies).
 */
export default function StatsPanel({ className, variant = "web" }: StatsPanelProps) {
  return (
    <div className={clsx("space-y-4", className)}>
      <GlassCard className="!bg-ink text-white" as="div">
        <p className="text-xs text-white/50">Tâches aujourd&apos;hui</p>
        <p className="mt-1 font-display text-3xl font-bold">5</p>
        <p className="mt-2 text-xs text-white/40">détails →</p>
      </GlassCard>

      <GlassCard>
        <p className="text-xs text-ink/40">Cartes révisées ce mois</p>
        <div className="mt-1 flex items-end justify-between">
          <p className="font-display text-3xl font-bold text-ink">42</p>
          <div className="h-10 w-24">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={RETENTION_DATA}>
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#33D6A6"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </GlassCard>

      {variant === "web" && (
        <GlassCard>
          <div className="mb-3 flex items-center justify-between">
            <p className="font-display text-sm font-semibold text-ink">Temps de focus</p>
            <span className="flex items-center gap-1 text-xs font-medium text-accent-orange">
              🔥 3h 40m
            </span>
          </div>
          <div className="flex h-28 items-end justify-between gap-2">
            {FOCUS_BARS.map((bar) => (
              <div key={bar.label} className="flex flex-1 flex-col items-center gap-2">
                <div
                  className={clsx("w-full rounded-xl", bar.color)}
                  style={{ height: `${bar.value}%` }}
                />
                <span className={clsx("text-[10px]", bar.active ? "font-semibold text-ink" : "text-ink/40")}>
                  {bar.label}
                </span>
              </div>
            ))}
          </div>
        </GlassCard>
      )}
    </div>
  );
}
