"use client";

import { Search, Bell, Wifi, WifiOff, RefreshCw } from "lucide-react";
import clsx from "clsx";
import FlowPlayer from "@/components/ui/FlowPlayer";
import type { SyncStatus } from "@/types";

interface AppHeaderProps {
  userName: string;
  status: SyncStatus;
  variant?: "mobile" | "web";
}

const STATUS_LABEL: Record<SyncStatus, string> = {
  online: "En ligne",
  syncing: "Synchronisation…",
  offline: "Mode hors-ligne",
};

/**
 * Header global commun (mobile + web).
 * Affiche l'indicateur réseau/sync (fonctionnalité 9. Cloud Sync) :
 * discret sur mobile, statut détaillé sur web.
 */
export default function AppHeader({ userName, status, variant = "web" }: AppHeaderProps) {
  return (
    <header className="flex items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <img
          src="https://api.dicebear.com/9.x/notionists/svg?seed=studyapp"
          alt=""
          className="h-11 w-11 rounded-full bg-white/60 object-cover"
        />
        <div>
          <p className="text-xs text-ink/40">Bonjour,</p>
          <p className="font-display text-lg font-semibold text-ink">{userName}</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {variant === "web" && (
          <div className="hidden items-center gap-2 rounded-full glass-surface px-4 py-2 md:flex">
            <Search size={14} className="text-ink/40" />
            <input
              placeholder="Rechercher une note, une carte…"
              className="w-48 bg-transparent text-sm text-ink outline-none placeholder:text-ink/30"
              aria-label="Recherche"
            />
          </div>
        )}

        {variant === "web" && <FlowPlayer variant="full" />}
        {variant === "mobile" && <FlowPlayer variant="compact" />}

        <div
          className={clsx(
            "flex items-center gap-1.5 rounded-full px-3 py-2 text-xs font-medium glass-surface",
            status === "offline" && "text-ink/40",
            status === "syncing" && "text-accent-blue",
            status === "online" && "text-accent-teal"
          )}
          title={STATUS_LABEL[status]}
        >
          {status === "offline" && <WifiOff size={13} />}
          {status === "syncing" && <RefreshCw size={13} className="animate-spin" />}
          {status === "online" && <Wifi size={13} />}
          {variant === "web" && <span>{STATUS_LABEL[status]}</span>}
        </div>

        <button
          aria-label="Notifications"
          className="grid h-10 w-10 place-items-center rounded-full bg-accent-orange text-white"
        >
          <Bell size={16} />
        </button>
      </div>
    </header>
  );
}
