"use client";

import GlassCard from "@/components/ui/GlassCard";
import Sidebar from "@/components/ui/Sidebar";
import AppHeader from "@/components/dashboard/AppHeader";
import AdvancedWeeklyPlanner from "@/components/dashboard/AdvancedWeeklyPlanner";
import NoteEditor from "@/components/notebook/NoteEditor";
import FlashcardQuiz from "@/components/dashboard/FlashcardQuiz";
import StatsPanel from "@/components/dashboard/StatsPanel";
import type { SyncStatus } from "@/types";

interface AdvancedDashboardWebProps {
  userName: string;
  status: SyncStatus;
}

/**
 * Intégration Web (Bento) — grille Next.js / Tailwind reproduisant la
 * disposition du mockup desktop : sidebar sombre, header global, widget
 * de planning en haut, éditeur de note en cellule principale, quiz SM-2
 * en colonne latérale, statistiques à droite.
 */
export default function AdvancedDashboardWeb({ userName, status }: AdvancedDashboardWebProps) {
  return (
    <div className="mx-auto flex h-screen max-w-[1440px] gap-4 p-4">
      <Sidebar />

      <div className="flex flex-1 flex-col gap-4 overflow-y-auto thin-scrollbar">
        <AppHeader userName={userName} status={status} variant="web" />

        <div className="grid flex-1 grid-cols-1 gap-4 lg:grid-cols-3">
          {/* Colonne principale : planning + notes */}
          <div className="flex flex-col gap-4 lg:col-span-2">
            <AdvancedWeeklyPlanner />

            <div className="grid grid-cols-2 gap-4">
              <GlassCard className="!bg-accent-orange text-white">
                <p className="text-xs text-white/70">Notes actives</p>
                <p className="mt-1 font-display text-2xl font-bold">12</p>
              </GlassCard>
              <GlassCard className="!bg-accent-yellow text-white">
                <p className="text-xs text-white/70">Cartes dues aujourd&apos;hui</p>
                <p className="mt-1 font-display text-2xl font-bold">8</p>
              </GlassCard>
            </div>

            <NoteEditor className="flex-1" />
          </div>

          {/* Colonne latérale droite : quiz + statistiques */}
          <div className="flex flex-col gap-4">
            <FlashcardQuiz />
            <StatsPanel variant="web" />
          </div>
        </div>
      </div>
    </div>
  );
}
