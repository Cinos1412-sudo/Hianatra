"use client";

import { useEffect, useState, useCallback } from "react";
import { db, getUnsyncedCount } from "@/utils/db";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import type { SyncStatus } from "@/types";

/**
 * Hook global de synchronisation en arrière-plan.
 *
 * - Aucune écriture n'attend le réseau : tout part d'abord dans Dexie.
 * - Ce hook observe `navigator.onLine`, puis pousse les enregistrements
 *   marqués `synced: false` vers Supabase dès que la connexion revient.
 * - Tant que Supabase n'est pas configuré (clés vides), le statut affiché
 *   reste "Hors-ligne" / mode local uniquement, sans jamais bloquer l'UI.
 */
export function useBackgroundSync() {
  const [isOnline, setIsOnline] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);

  const refreshPendingCount = useCallback(async () => {
    const count = await getUnsyncedCount();
    setPendingCount(count);
  }, []);

  const runSync = useCallback(async () => {
    if (!db || !supabase || !isSupabaseConfigured) return;
    if (!navigator.onLine) return;

    setIsSyncing(true);
    try {
      const unsyncedNotes = await db.notes.filter((n) => !n.synced).toArray();
      const unsyncedCards = await db.flashcards.filter((c) => !c.synced).toArray();
      const unsyncedBlocks = await db.plannerBlocks.filter((b) => !b.synced).toArray();

      if (unsyncedNotes.length) {
        await supabase.from("notes").upsert(unsyncedNotes.map(({ id, ...rest }) => rest));
        await db.notes.bulkPut(unsyncedNotes.map((n) => ({ ...n, synced: true })));
      }
      if (unsyncedCards.length) {
        await supabase.from("flashcards").upsert(unsyncedCards.map(({ id, ...rest }) => rest));
        await db.flashcards.bulkPut(unsyncedCards.map((c) => ({ ...c, synced: true })));
      }
      if (unsyncedBlocks.length) {
        await supabase.from("planner_blocks").upsert(unsyncedBlocks.map(({ id, ...rest }) => rest));
        await db.plannerBlocks.bulkPut(unsyncedBlocks.map((b) => ({ ...b, synced: true })));
      }
    } catch (err) {
      // Le réseau peut retomber en plein milieu : on réessaiera au prochain
      // évènement "online" ou à l'intervalle suivant, sans jamais faire
      // planter l'UI.
      console.warn("Sync Supabase interrompue, nouvelle tentative plus tard.", err);
    } finally {
      setIsSyncing(false);
      await refreshPendingCount();
    }
  }, [refreshPendingCount]);

  useEffect(() => {
    setIsOnline(navigator.onLine);
    refreshPendingCount();

    const handleOnline = () => {
      setIsOnline(true);
      runSync();
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    // Tentative de sync périodique (ex. toutes les 30s) si en ligne.
    const interval = setInterval(() => {
      if (navigator.onLine) runSync();
    }, 30000);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
      clearInterval(interval);
    };
  }, [runSync, refreshPendingCount]);

  const status: SyncStatus = !isOnline ? "offline" : isSyncing ? "syncing" : "online";

  return { isOnline, isSyncing, pendingCount, status, isSupabaseConfigured, forceSync: runSync };
}
