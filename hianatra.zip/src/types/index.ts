export interface Note {
  id?: number;
  uuid: string;
  title: string;
  content: string;
  drawingBase64?: string | null;
  color: "orange" | "yellow" | "pink" | "blue" | "teal";
  createdAt: string;
  updatedAt: string;
  synced: boolean;
}

export interface Flashcard {
  id?: number;
  uuid: string;
  noteId?: string;
  question: string;
  answer: string;
  repetitions: number;
  interval: number;
  easeFactor: number;
  dueDate: string;
  synced: boolean;
}

export interface PlannerBlock {
  id?: number;
  uuid: string;
  title: string;
  subtitle?: string;
  day: string; // ISO date
  startHour: number;
  endHour: number;
  color: "orange" | "yellow" | "pink" | "blue" | "teal";
  synced: boolean;
}

export type SyncStatus = "online" | "syncing" | "offline";
